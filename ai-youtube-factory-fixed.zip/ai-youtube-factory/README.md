# 🎬 AI YouTube Factory

Automated AI pipeline: **script → voiceover → video → thumbnail → YouTube upload**.

## Stack
- **Backend:** Node.js + Express + TypeScript
- **Frontend:** React + Vite + TypeScript
- **APIs:** OpenAI (script + DALL·E 3), ElevenLabs (TTS), YouTube Data API v3, FFmpeg (assembly)

## Quick start (no API keys needed)
```bash
git clone <your-repo-url>
cd ai-youtube-factory
cp .env.example .env
# set MOCK_MODE=true in .env
npm install
npm run dev
```
Open http://localhost:5173 — the pipeline runs without external API keys. It creates a valid MP3 containing silence, a valid PNG thumbnail, and a playable MP4 in `./tmp`. Mock mode does not generate spoken narration or upload a real YouTube video. **FFmpeg must be installed and available on PATH.**

## Real mode setup

### 1. FFmpeg
```bash
# macOS
brew install ffmpeg
# Ubuntu/Debian
sudo apt install ffmpeg
# Windows (winget)
winget install Gyan.FFmpeg
```

### 2. OpenAI key
Create at https://platform.openai.com/api-keys → `OPENAI_API_KEY`

### 3. ElevenLabs key
Create at https://elevenlabs.io → `ELEVENLABS_API_KEY`
Pick a voice ID from https://elevenlabs.io/voice-library → `ELEVENLABS_VOICE_ID`

### 4. YouTube OAuth2
1. Go to https://console.cloud.google.com/ → create a project
2. Enable **YouTube Data API v3**
3. Create **OAuth client ID** (type: Web application)
4. Add redirect URI: `http://localhost:3001/auth/youtube/callback`
5. Put `YOUTUBE_CLIENT_ID` + `YOUTUBE_CLIENT_SECRET` in `.env`
6. Start the server and visit:
   - `http://localhost:3001/auth/youtube/url` → open the returned URL
   - Authorize → copy the `refresh_token` from the callback response into `.env`

## How it works
| Step | File | Provider |
|------|------|----------|
| Script + metadata | `services/script.service.ts` | OpenAI GPT |
| Voiceover | `services/voiceover.service.ts` | ElevenLabs |
| Thumbnail | `services/thumbnail.service.ts` | DALL·E 3 |
| Video assembly | `services/video.service.ts` | FFmpeg |
| Upload | `services/youtube.service.ts` | YouTube API |

The pipeline runs as a background job. `POST /api/videos` returns a `jobId`, and the frontend polls `GET /api/jobs/:id`.

## API
| Method | Route | Description |
|--------|-------|-------------|
| `POST` | `/api/videos` | `{ topic }` → starts a job |
| `GET` | `/api/jobs` | List all jobs |
| `GET` | `/api/jobs/:id` | Job status + result |
| `GET` | `/auth/youtube/url` | Get OAuth consent URL |
| `GET` | `/auth/youtube/callback` | Returns refresh token |

## ⚠️ Important notes
- **YouTube quota:** Uploads consume quota units; check the current quota in Google Cloud Console.
- **Videos upload as `private`** by default. Change `privacyStatus` in `youtube.service.ts` to go public.
- **Job storage is in-memory.** For production, swap the `Map` in `pipeline.service.ts` for Redis/Postgres.
- **AI video generation** (Runway/Veo/Seedance) is a plug-in point in `video.service.ts` — the current FFmpeg path renders a still-image + audio video. In mock mode the audio is silent; real narration requires an ElevenLabs API key. FFmpeg must be installed in the runtime environment.
- **Mock mode media is playable but silent.** It creates a valid silent MP3, a valid PNG thumbnail, and a playable MP4 so the pipeline can be tested without API keys. It does not generate spoken narration or upload a real YouTube video.
- **Deployment:** configure `VITE_API_BASE_URL` for the frontend build and set `FRONTEND_ORIGIN` to the deployed frontend origin on the backend.

## License
MIT

## Frontend deployment configuration

The frontend reads `VITE_API_BASE_URL` at build time. For local development, the default is `http://localhost:3001`. For a deployed frontend, set `VITE_API_BASE_URL` to the public URL of your deployed backend (for example, `https://your-backend.example.com`) in the frontend hosting provider. Also set the backend `FRONTEND_ORIGIN` to the deployed frontend origin.

**Deployment note:** this project uses an Express server and in-memory background jobs, so it is not a drop-in Vercel serverless deployment. Deploy the backend to a Node host that supports long-running processes and FFmpeg, or adapt the API and job processing to your hosting platform.
