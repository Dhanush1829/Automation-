import 'dotenv/config';

export const config = {
  port: Number(process.env.PORT ?? 3001),
  frontendOrigin: process.env.FRONTEND_ORIGIN ?? 'http://localhost:5173',
  mockMode: process.env.MOCK_MODE === 'true',
  tmpDir: process.env.TMP_DIR ?? './tmp',

  openaiKey: process.env.OPENAI_API_KEY ?? '',

  elevenLabsKey: process.env.ELEVENLABS_API_KEY ?? '',
  elevenLabsVoiceId: process.env.ELEVENLABS_VOICE_ID ?? '21m00Tcm4TlvDq8ikWAM',

  youtube: {
    clientId: process.env.YOUTUBE_CLIENT_ID ?? '',
    clientSecret: process.env.YOUTUBE_CLIENT_SECRET ?? '',
    redirectUri:
      process.env.YOUTUBE_REDIRECT_URI ??
      'http://localhost:3001/auth/youtube/callback',
    refreshToken: process.env.YOUTUBE_REFRESH_TOKEN ?? '',
  },
};

export function validateConfig(): void {
  if (config.mockMode) {
    console.log('⚠️  MOCK_MODE enabled — no external APIs will be called.');
    return;
  }
  const missing: string[] = [];
  if (!config.openaiKey) missing.push('OPENAI_API_KEY');
  if (!config.elevenLabsKey) missing.push('ELEVENLABS_API_KEY');
  if (!config.youtube.clientId) missing.push('YOUTUBE_CLIENT_ID');
  if (!config.youtube.clientSecret) missing.push('YOUTUBE_CLIENT_SECRET');
  if (!config.youtube.refreshToken) missing.push('YOUTUBE_REFRESH_TOKEN');

  if (missing.length) {
    console.warn(`⚠️  Missing env vars: ${missing.join(', ')}`);
    console.warn('    Set MOCK_MODE=true in .env to test without API keys.');
  }
}
