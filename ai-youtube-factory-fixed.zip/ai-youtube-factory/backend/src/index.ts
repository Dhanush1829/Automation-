import express from 'express';
import cors from 'cors';
import { config, validateConfig } from './config.js';
import authRoutes from './routes/auth.js';
import videoRoutes from './routes/videos.js';

const app = express();
app.use(cors({ origin: config.frontendOrigin }));
app.use(express.json());

app.get('/health', (_req, res) => res.json({ ok: true }));
app.use('/auth', authRoutes);
app.use('/api', videoRoutes);

// Error handler
app.use(
  (
    err: unknown,
    _req: express.Request,
    res: express.Response,
    _next: express.NextFunction
  ) => {
    console.error('Unhandled error:', err);
    res.status(500).json({
      error: err instanceof Error ? err.message : 'Internal server error',
    });
  }
);

validateConfig();
app.listen(config.port, () => {
  console.log(`🚀 Backend running on http://localhost:${config.port}`);
});
