import { execFile } from 'node:child_process';
import { promisify } from 'node:util';

const execFileAsync = promisify(execFile);

/**
 * Renders a valid MP4 from a still image and audio track using FFmpeg.
 * Mock mode uses a real placeholder image and silent MP3, so the result is
 * playable (but has no spoken narration). Install FFmpeg and put it on PATH.
 *
 * 🔌 Plug in Runway / Veo / Seedance here for AI-generated footage.
 */
export async function renderVideo(params: {
  imagePath: string;
  audioPath: string;
  outPath: string;
}): Promise<string> {
  const { imagePath, audioPath, outPath } = params;

  try {
    await execFileAsync('ffmpeg', [
      '-hide_banner', '-loglevel', 'error', '-y',
      '-loop', '1', '-framerate', '30', '-i', imagePath,
      '-i', audioPath,
      '-vf', 'scale=1280:720:force_original_aspect_ratio=decrease,pad=1280:720:(ow-iw)/2:(oh-ih)/2,format=yuv420p',
      '-c:v', 'libx264', '-preset', 'veryfast', '-tune', 'stillimage',
      '-c:a', 'aac', '-b:a', '128k', '-shortest', '-movflags', '+faststart',
      outPath,
    ]);
    return outPath;
  } catch (err) {
    throw new Error(`FFmpeg could not render the MP4. Install FFmpeg and ensure it is on PATH. ${err instanceof Error ? err.message : String(err)}`);
  }
}
