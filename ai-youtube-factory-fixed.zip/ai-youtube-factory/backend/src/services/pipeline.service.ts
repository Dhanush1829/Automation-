import path from 'node:path';
import fs from 'node:fs/promises';
import { randomUUID } from 'node:crypto';
import { config } from '../config.js';
import type { Job } from '../types.js';
import { generateScript } from './script.service.js';
import { generateVoiceover } from './voiceover.service.js';
import { generateThumbnail } from './thumbnail.service.js';
import { renderVideo } from './video.service.js';
import { uploadToYouTube } from './youtube.service.js';

// ⚠️ In-memory store. Swap for Redis/Postgres in production.
const jobs = new Map<string, Job>();

export function getJob(id: string): Job | undefined {
  return jobs.get(id);
}

export function listJobs(): Job[] {
  return [...jobs.values()].sort((a, b) => b.createdAt.localeCompare(a.createdAt));
}

export function createJob(topic: string): Job {
  const job: Job = {
    id: randomUUID(),
    topic,
    status: 'queued',
    step: 'queued',
    createdAt: new Date().toISOString(),
  };
  jobs.set(job.id, job);
  void runJob(job);
  return job;
}

async function runJob(job: Job): Promise<void> {
  const workDir = path.join(config.tmpDir, job.id);
  const audioPath = path.join(workDir, 'voiceover.mp3');
  const imagePath = path.join(workDir, 'thumbnail.png');
  const videoPath = path.join(workDir, 'video.mp4');

  try {
    await fs.mkdir(workDir, { recursive: true });
    job.status = 'running';

    // 1. Script
    job.step = 'generating script';
    const meta = await generateScript(job.topic);

    // 2. Voiceover
    job.step = 'generating voiceover';
    await generateVoiceover(meta.script, audioPath);

    // 3. Thumbnail
    job.step = 'generating thumbnail';
    await generateThumbnail(meta.title, imagePath);

    // 4. Video assembly
    job.step = 'rendering video';
    await renderVideo({ imagePath, audioPath, outPath: videoPath });

    // 5. Upload
    job.step = 'uploading to YouTube';
    const videoId = await uploadToYouTube({
      videoPath,
      thumbnailPath: imagePath,
      meta,
      privacyStatus: 'private',
    });

    job.status = 'done';
    job.step = 'complete';
    job.result = {
      videoId,
      title: meta.title,
      youtubeUrl:
        videoId.startsWith('MOCK')
          ? `(mock) ${meta.title}`
          : `https://youtu.be/${videoId}`,
      thumbnailUrl: '',
      files: { video: videoPath, audio: audioPath, thumbnail: imagePath },
    };
  } catch (err) {
    job.status = 'error';
    job.step = 'failed';
    job.error = err instanceof Error ? err.message : String(err);
    console.error(`❌ Job ${job.id} failed:`, err);
  }
}
