import fs from 'node:fs/promises';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { config } from '../config.js';

const execFileAsync = promisify(execFile);

export async function generateVoiceover(
  text: string,
  outPath: string
): Promise<string> {
  if (config.mockMode || !config.elevenLabsKey) {
    // Produce a real, playable silent MP3 in mock mode instead of a text file
    // with an .mp3 extension. This lets the complete pipeline be tested safely.
    const durationSeconds = Math.max(3, Math.min(30, Math.ceil(text.length / 18)));
    try {
      await execFileAsync('ffmpeg', [
        '-hide_banner', '-loglevel', 'error', '-y',
        '-f', 'lavfi', '-i', 'anullsrc=r=44100:cl=stereo',
        '-t', String(durationSeconds),
        '-codec:a', 'libmp3lame', '-b:a', '96k',
        '-f', 'mp3', outPath,
      ]);
    } catch (err) {
      throw new Error(`Could not create mock MP3. Install FFmpeg and ensure it is on PATH. ${err instanceof Error ? err.message : String(err)}`);
    }
    return outPath;
  }

  const res = await fetch(
    `https://api.elevenlabs.io/v1/text-to-speech/${config.elevenLabsVoiceId}`,
    {
      method: 'POST',
      headers: {
        'xi-api-key': config.elevenLabsKey,
        'Content-Type': 'application/json',
        Accept: 'audio/mpeg',
      },
      body: JSON.stringify({
        text,
        model_id: 'eleven_multilingual_v2',
        voice_settings: { stability: 0.5, similarity_boost: 0.75 },
      }),
    }
  );

  if (!res.ok) {
    const detail = await res.text().catch(() => '');
    throw new Error(`ElevenLabs error ${res.status}: ${detail}`);
  }

  await fs.writeFile(outPath, Buffer.from(await res.arrayBuffer()));
  return outPath;
}
