import fs from 'node:fs/promises';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import OpenAI from 'openai';
import { config } from '../config.js';

const execFileAsync = promisify(execFile);
const client = config.openaiKey ? new OpenAI({ apiKey: config.openaiKey }) : null;

/** Generates a thumbnail image file and returns its path. */
export async function generateThumbnail(
  title: string,
  outPath: string
): Promise<string> {
  if (config.mockMode || !client) {
    // Create a real 1280x720 PNG, not a 1x1 placeholder. FFmpeg is also used
    // for mock audio/video so local mock-mode output remains a valid media file.
    try {
      await execFileAsync('ffmpeg', [
        '-hide_banner', '-loglevel', 'error', '-y',
        '-f', 'lavfi', '-i', 'color=c=0x111827:s=1280x720',
        '-frames:v', '1', '-update', '1', outPath,
      ]);
    } catch (err) {
      throw new Error(`Could not create mock thumbnail. Install FFmpeg and ensure it is on PATH. ${err instanceof Error ? err.message : String(err)}`);
    }
    return outPath;
  }

  const image = await client.images.generate({
    model: 'dall-e-3',
    prompt:
      `High-CTR YouTube thumbnail for a video titled "${title}". ` +
      'Bold composition, vivid colors, dramatic lighting, no text overlays.',
    n: 1,
    size: '1792x1024',
    quality: 'standard',
  });

  const url = image.data?.[0]?.url;
  if (!url) throw new Error('OpenAI image generation returned no image URL.');

  const res = await fetch(url);
  if (!res.ok) throw new Error(`Failed to download thumbnail: ${res.status}`);

  await fs.writeFile(outPath, Buffer.from(await res.arrayBuffer()));
  return outPath;
}
