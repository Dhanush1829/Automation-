import OpenAI from 'openai';
import { config } from '../config.js';
import type { VideoScript } from '../types.js';

const client = config.openaiKey
  ? new OpenAI({ apiKey: config.openaiKey })
  : null;

const SYSTEM_PROMPT =
  'You are an expert YouTube scriptwriter. Write concise, engaging, ' +
  'retention-optimized content. The script must read naturally when spoken aloud.';

export async function generateScript(topic: string): Promise<VideoScript> {
  if (config.mockMode || !client) {
    return {
      title: `Mock Video: ${topic}`,
      description: `This is a mock description for "${topic}" generated in MOCK_MODE.`,
      tags: [topic, 'ai', 'automation'],
      script:
        `Welcome to this mock video about ${topic}. ` +
        `This placeholder script is generated because MOCK_MODE is enabled. ` +
        `Add your API keys to generate real content.`,
    };
  }

  const completion = await client.chat.completions.create({
    model: 'gpt-4o-mini',
    temperature: 0.8,
    response_format: {
      type: 'json_schema',
      json_schema: {
        name: 'video_script',
        strict: true,
        schema: {
          type: 'object',
          additionalProperties: false,
          required: ['title', 'description', 'tags', 'script'],
          properties: {
            title: {
              type: 'string',
              description: 'YouTube title, <= 90 chars, high CTR.',
            },
            description: {
              type: 'string',
              description: 'YouTube description, 2-4 sentences.',
            },
            tags: {
              type: 'array',
              items: { type: 'string' },
              description: '5-10 SEO tags.',
            },
            script: {
              type: 'string',
              description: 'Spoken script, roughly 150-300 words.',
            },
          },
        },
      },
    },
    messages: [
      { role: 'system', content: SYSTEM_PROMPT },
      { role: 'user', content: `Write a 60-second YouTube script about: "${topic}".` },
    ],
  });

  const raw = completion.choices[0]?.message?.content;
  if (!raw) throw new Error('OpenAI returned an empty script response.');
  return JSON.parse(raw) as VideoScript;
}
