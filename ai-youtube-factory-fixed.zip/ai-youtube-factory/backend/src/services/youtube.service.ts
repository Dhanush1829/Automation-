import fs from 'node:fs';
import { google } from 'googleapis';
import { config } from '../config.js';
import type { VideoScript } from '../types.js';

function createClient() {
  const auth = new google.auth.OAuth2(
    config.youtube.clientId,
    config.youtube.clientSecret,
    config.youtube.redirectUri
  );
  auth.setCredentials({ refresh_token: config.youtube.refreshToken });
  return google.youtube({ version: 'v3', auth });
}

export async function uploadToYouTube(params: {
  videoPath: string;
  thumbnailPath: string;
  meta: VideoScript;
  privacyStatus?: 'private' | 'unlisted' | 'public';
}): Promise<string> {
  const { videoPath, thumbnailPath, meta } = params;
  const privacyStatus = params.privacyStatus ?? 'private';

  if (config.mockMode || !config.youtube.refreshToken) {
    return `MOCK_VIDEO_ID_${Date.now()}`;
  }

  const youtube = createClient();

  const uploaded = await youtube.videos.insert({
    part: ['snippet', 'status'],
    requestBody: {
      snippet: {
        title: meta.title.slice(0, 100),
        description: meta.description,
        tags: meta.tags,
        categoryId: '28',
      },
      status: {
        privacyStatus,
        selfDeclaredMadeForKids: false,
      },
    },
    media: { body: fs.createReadStream(videoPath) },
  });

  const videoId = uploaded.data.id;
  if (!videoId) throw new Error('YouTube upload returned no video ID.');

  try {
    await youtube.thumbnails.set({
      videoId,
      media: { body: fs.createReadStream(thumbnailPath) },
    });
  } catch (err) {
    console.warn('⚠️  Thumbnail upload failed (video still uploaded).', err);
  }

  return videoId;
}
