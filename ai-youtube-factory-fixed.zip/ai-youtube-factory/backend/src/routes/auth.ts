import { Router } from 'express';
import { google } from 'googleapis';
import { config } from '../config.js';
import { asyncHandler } from '../utils/asyncHandler.js';

const router = Router();

function oauthClient() {
  return new google.auth.OAuth2(
    config.youtube.clientId,
    config.youtube.clientSecret,
    config.youtube.redirectUri
  );
}

// GET /auth/youtube/url → returns the Google consent URL
router.get('/youtube/url', (req, res) => {
  const url = oauthClient().generateAuthUrl({
    access_type: 'offline',
    prompt: 'consent',
    scope: ['https://www.googleapis.com/auth/youtube.upload'],
  });
  res.json({ url });
});

// GET /auth/youtube/callback?code=... → returns the refresh token
router.get(
  '/youtube/callback',
  asyncHandler(async (req, res) => {
    const code = String(req.query.code ?? '');
    if (!code) {
      res.status(400).json({ error: 'Missing ?code parameter' });
      return;
    }
    const { tokens } = await oauthClient().getToken(code);
    res.json({
      message: 'Copy YOUTUBE_REFRESH_TOKEN into your .env file.',
      refresh_token: tokens.refresh_token,
      access_token: tokens.access_token,
    });
  })
);

export default router;
