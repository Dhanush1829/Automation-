import { Router } from 'express';
import { z } from 'zod';
import { asyncHandler } from '../utils/asyncHandler.js';
import { createJob, getJob, listJobs } from '../services/pipeline.service.js';

const router = Router();

const CreateSchema = z.object({
  topic: z.string().min(3).max(200),
});

// POST /api/videos
router.post(
  '/videos',
  asyncHandler(async (req, res) => {
    const parsed = CreateSchema.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: 'Invalid body', issues: parsed.error.issues });
      return;
    }
    const job = createJob(parsed.data.topic);
    res.status(202).json({ jobId: job.id, status: job.status });
  })
);

// GET /api/jobs
router.get('/jobs', (_req, res) => {
  res.json({ jobs: listJobs() });
});

// GET /api/jobs/:id
router.get('/jobs/:id', (req, res) => {
  const job = getJob(req.params.id);
  if (!job) {
    res.status(404).json({ error: 'Job not found' });
    return;
  }
  res.json(job);
});

export default router;
