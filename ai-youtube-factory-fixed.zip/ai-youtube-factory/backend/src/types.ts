export interface VideoScript {
  title: string;
  description: string;
  tags: string[];
  script: string;
}

export type JobStatus = 'queued' | 'running' | 'done' | 'error';

export interface JobResult {
  videoId: string;
  title: string;
  youtubeUrl: string;
  thumbnailUrl: string;
  files: {
    video: string;
    audio: string;
    thumbnail: string;
  };
}

export interface Job {
  id: string;
  topic: string;
  status: JobStatus;
  step: string;
  createdAt: string;
  result?: JobResult;
  error?: string;
}
