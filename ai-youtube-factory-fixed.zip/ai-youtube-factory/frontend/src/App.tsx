import { useCallback, useEffect, useState } from 'react';

const API = (import.meta.env.VITE_API_BASE_URL || 'http://localhost:3001').replace(/\/$/, '');

interface Job {
  id: string;
  topic: string;
  status: 'queued' | 'running' | 'done' | 'error';
  step: string;
  error?: string;
  result?: {
    videoId: string;
    title: string;
    youtubeUrl: string;
    files: { video: string };
  };
}

export default function App() {
  const [topic, setTopic] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [jobs, setJobs] = useState<Job[]>([]);
  const [error, setError] = useState('');

  const refresh = useCallback(async () => {
    try {
      const res = await fetch(`${API}/api/jobs`);
      const data = await res.json();
      setJobs(data.jobs ?? []);
    } catch {
      /* server may not be up yet */
    }
  }, []);

  useEffect(() => {
    refresh();
    const id = setInterval(refresh, 2500);
    return () => clearInterval(id);
  }, [refresh]);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    setSubmitting(true);
    try {
      const res = await fetch(`${API}/api/videos`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ topic }),
      });
      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        throw new Error(data.error ?? `Request failed (${res.status})`);
      }
      setTopic('');
      await refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error');
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <main>
      <h1>🎬 AI YouTube Factory</h1>
      <p className="sub">
        Script → Voiceover → Video → Thumbnail → YouTube, fully automated.
      </p>

      <form onSubmit={handleSubmit}>
        <input
          value={topic}
          onChange={(e) => setTopic(e.target.value)}
          placeholder="e.g. The future of quantum computing"
          required
          minLength={3}
        />
        <button disabled={submitting || topic.trim().length < 3}>
          {submitting ? 'Starting…' : 'Generate Video'}
        </button>
      </form>

      {error && <p className="error">{error}</p>}

      <section>
        <h2>Jobs</h2>
        {jobs.length === 0 && <p className="muted">No jobs yet.</p>}
        <ul>
          {jobs.map((job) => (
            <li key={job.id} className={`job ${job.status}`}>
              <div className="job-head">
                <strong>{job.topic}</strong>
                <span className="badge">{job.status}</span>
              </div>
              <div className="job-step">{job.step}</div>
              {job.error && <div className="error">{job.error}</div>}
              {job.result && (
                <div className="job-result">
                  <div>
                    <strong>Title:</strong> {job.result.title}
                  </div>
                  <div>
                    <strong>Video ID:</strong> {job.result.videoId}
                  </div>
                  {!job.result.youtubeUrl.startsWith('(mock)') && (
                    <a
                      href={job.result.youtubeUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      Open on YouTube (private)
                    </a>
                  )}
                </div>
              )}
            </li>
          ))}
        </ul>
      </section>
    </main>
  );
}
